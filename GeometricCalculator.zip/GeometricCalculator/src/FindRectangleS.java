public class FindRectangleS
{
    public double Area;

    //Формула для нахождения площади
    public double areaCalculator(int num1,int num2){
        Area = (num1 * num2);
        return Area;
    }



    public void viewResult(){
        System.out.println("Площадь равна: "+Area);

    }


}
