


import java.util.Scanner;

public class main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("Введите 1 если это прямоугольник, или 2 если параллелограмм: ");
        int CH = sc.nextInt();
        if (CH == 1) {

            FindRectangleS rec = new FindRectangleS();
            Scanner in = new Scanner(System.in);

            System.out.println("Введите длину прямоугольника: ");
            int num1 = in.nextInt();
            System.out.println("Введите ширину прямоугольника: ");
            int num2 = in.nextInt();


            rec.areaCalculator(num1, num2);

            rec.viewResult();
        } else {
            FindRectangleS rec = new FindRectangleS();
            Scanner in = new Scanner(System.in);

            System.out.println("Введите длину высоты параллелограмма: ");
            int num1 = in.nextInt();
            System.out.println("Введите длину стороны к которой проведена высота параллелограмма: ");
            int num2 = in.nextInt();


            rec.areaCalculator(num1, num2);

            rec.viewResult();
        }
    }}